<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
   $sql = "select * from posts order by id desc";
   $posts = DB::select($sql);
   return view('Home')->with('posts', $posts);
   
});


Route::get('Comments/{id}', function ($id) {
    $sql = "select * from posts where id = '$id'";
    $posts = DB::select($sql);
    $comments = get_comments($id);
    return view('Comments')->with('comments', $comments)->with('posts', $posts);
});

Route::get('add_post', function(){
    return view('add_post');

});

Route::post('add_post_action', function(){
    $name = request('name');
    $title = request('title');
    $image = request('image');
    $description = request('description');
    $id = add_item($name, $title, $image, $description);
    

    if ($id) {
        return redirect("/");
    } else {
        die("Error while adding item");
    }

});

Route::get('add_comments', function(){
    return view('add_comments');

});

Route::post('add_comment_action', function(){
    $name = request('name');
    $image = request('image');
    $description = request('description');
    $post_id = request('post_id');
    $id = add_comment($name, $description, $image, $post_id);
    

    if ($id) {
        return redirect("/Comments/$post_id");
    } else {
        die("Error while adding item");
    }

});

Route::get('delete_comment_action/{id}', function($id){
    delete_comment($id);
    return redirect("/");


});

Route::post('update_post_action', function(){
    $name = request('name');
    $title = request('title');
    $image = request('image');
    $description = request('description');
    $id = request('id');
    $posts = update_post($name, $title, $image, $description, $id);
    

    if ($id) {
        return redirect("/Comments/$id");
    } else {
        die("Error while adding post");
    }

});

Route::get('update_post/{id}', function($id){
    $posts = get_post($id);
    return view('update_post')->with('posts', $posts);
    
});

Route::get('delete_post_action/{id}', function($id){
    delete_post($id);
    return redirect("/");


});

/*
The below function selects all data from the 'posts' array
*/

function get_post($id) {
    $sql = "select * from posts where id=?";
    $posts = DB::select($sql, array($id));
    
    if (count($posts) != 1){
        die("Something has gone wrong! Invalid Query or result: $sql");
    }
    
    $post = $posts[0];
    return $post;
}

/*
The below function selects all data from the 'comments' array as well as establish
the relationship
*/

function get_comments($id) {
    $sql = "select * from posts, comments where comments.post_id=posts.id and comments.post_id = ?";
    $comments = array(DB::select($sql, array($id)));

    if (count($comments) != 1){
        die("No comments found!");
    }
    
    $comment = $comments[0];
    return $comment;
}

/*
Adds a new post to the 'posts' database
*/

function add_post($name, $title, $image, $description){
    $sql = "insert into posts (name, title, image, description) values (?, ?, ?, ?)";
    DB::insert($sql, array($name, $title, $image, $description));
    $id = DB::getPdo()->lastInsertId();
    return($id);
    
} 

/*
Adds a new comment to the 'comments' database
One other development issue is the fact that I could not
'auto-insert' the post_id so the user has to enter it
*/

function add_comment($name, $description, $image, $post_id){
    $sql = "insert into comments (name, description, image, post_id) values (?, ?, ?, ?)";
    DB::insert($sql, array($name, $description, $image, $post_id));
    $id = DB::getPdo()->lastInsertId();
    return($id);
    
} 

/*
Delete a comment
*/

function delete_comment($id) {
    $sql = "delete from comments where id = ?";
    DB::delete($sql, array($id));
    
} 

/*
Uses similar functions to add_post() except it uses
DB::update, updating the post
*/

function update_post($name, $title, $image, $description, $id){
    $sql = "update posts set name = ?, title = ?, image = ?, description = ? where id = ?";
    DB::update($sql, array($name, $title, $image, $description, $id));

} 

/*
Deletes a post as well as the comments attached to it
*/

function delete_post($id) {
    $comments = get_comments($id);
    $comments_id = array_column($comments, 'id'); 
    
    foreach ($comments_id as $comment_id){
        delete_comment($comment_id);
    }
    
    $sql = "delete from posts where id = ?";
    DB::delete($sql, array($id));
    
} 