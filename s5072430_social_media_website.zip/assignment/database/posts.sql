drop table if exists posts;
create table posts (    
    id integer not null primary key autoincrement,    
    name varchar(80) not null, 
    title varchar(80) not null,
    description text default '',
    image varchar(120)
); 
insert into posts values (null, "Zane Stevens", "Php", "Php is great", "beard.jpg");
insert into posts values (null, "Arin Hanson","The Power of Burgie", "No one likes burgers", "beard.jpg");
insert into posts values (null, "Daniel Avidan", "Topic on Seafood", "Clams are great", "beard.jpg");
insert into posts values (null, "Jon Jafari","Ech", "Ech", "beard.jpg");
insert into posts values (null, "Barry","Editing Skills", "Zoom in on that!", "beard.jpg");

drop table if exists comments;
create table comments (    
    id integer not null primary key autoincrement,    
    name varchar(80) not null,    
    description text default '',
    image varchar(120),
    post_id integer not null,
    FOREIGN KEY(post_id) REFERENCES posts(id)
); 
insert into comments values (null, "Barry",  "Zoom in on THAT!", "big-fork-black.jpg", 1);
insert into comments values (null, "Jon Jafari", "....", "big-fork-black.jpg", 1);
insert into comments values (null, "Arin Hanson",  "CLAM!", "big-fork-black.jpg", 4);
insert into comments values (null, "Daniel Avidan", "ECH!", "big-fork-black.jpg", 2);
insert into comments values (null, "Kevin", "What are you doing Barry?", "big-fork-black.jpg", 5);
insert into comments values (null, "Barry", "Everything!", "big-fork-black.jpg", 5);