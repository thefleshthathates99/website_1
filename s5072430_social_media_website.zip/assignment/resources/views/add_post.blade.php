@extends('layouts.master')
@section('title')
Add New Post
@endsection
@section('content')
<h1>Add New Post</h1>
<div class="container2">
   <form method="post" action="/add_post_action">
      {{csrf_field()}}
      <p>
         <label>Your Name:</label><br>
         <input type="text" name="name">
      </p>
      <p>
         <label>Title of your Post:</label><br>
         <input type="text" name="title">
      </p>
      <p>
         <label>Image:</label><br>
         <input type="hidden" name="image" value="beard.jpg">
      </p>
      <p>
         <label>Description:</label><br>
         <textarea name="description"></textarea>
      </p>
      <input type="submit" value="Add Post">
   </form>
   <br>
   <br>
</div>
@endsection