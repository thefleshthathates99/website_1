@extends('layouts.master')

@section('title')
Comments
@endsection

@section('content')
<a href="{{url("/add_comments")}}">Add a Comment</a>
@foreach ($posts as $post)
<div class="container3">
   <h1 class="bold">{{$post->name}}</h1>
   <h1 class="bold">{{$post->title}}</h1>
   <h2 class="bold">{{$post->description}}</h2>
   <div class="bold"><img src="../{{$post->image}}" width=100px height=100px></div>
   <a href="{{url("update_post/$post->id")}}">Update Post</a>
   <br>
   <a href="{{url("delete_post_action/$post->id")}}">Delete Post</a>
   </p> 
</div>
@endforeach
@foreach ($comments as $comment)
<div class="container2">
   <p>
   <h1>{{$comment->name}}</h1>
   <h1>{{$comment->description}}</h1>
   <h2><img src="../{{$comment->image}}" width=100px height=100px></h2>
   </p> 
   <br>
   <a href="{{url("delete_comment_action/$comment->id")}}">Delete Comment</a>
</div>
@endforeach
@endsection