@extends('layouts.master')

@section('title')
  Post Details
@endsection


@section('content')
<div class="container2">
    <p>
    <h1>{{$posts->name}}</h1>
    <h1>{{$posts->title}}</h1>
    <h2>{{$posts->description}}</h2>
    {{$posts->image}}
   </p> 
    <p>
    <a href="{{url("/Comments/$posts->id")}}">Comments</a>
        </p>    
</div>
@endsection