@extends('layouts.master')

@section('title')
Home
@endsection

@section('stylesheet')
<link rel="stylesheet" type="text/css" href="css/style.css">
@endsection
@section('content')
<body>
   <div class="container">
      Welcome to the Washington Redskins social media website
   </div>
   <br>
   <p>
      <a href="{{url("/add_post")}}">Add a New Post</a>
   </p>
   @foreach ($posts as $post)
   <div class="container2">
      <h1>{{$post->name}}</h1>
      <h1>{{$post->title}}</h1>
      <h2>{{$post->description}}</h2>
      <img src="{{$post->image}}" width=100px height=100px>
      <br>
      <a href="{{url("update_post/$post->id")}}">Update Post</a>
      </p>
      <p>
         <a href="{{url("/Comments/$post->id")}}">Comments</a>
      </p>
      <br>
   </div>
   @endforeach
   @endsection