<?php $__env->startSection('title'); ?>
  Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('stylesheet'); ?>
<link rel="stylesheet" type="text/css" href="css/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<body>
<div class="container">
Welcome to the Washington Redskins social media website
</div>
<br>
    <p>
        <a href="<?php echo e(url("/add_post")); ?>">Add a New Post</a>
   </p>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container2">
    <h1><?php echo e($post->name); ?></h1>
    <h1><?php echo e($post->title); ?></h1>
    <h2><?php echo e($post->description); ?></h2>
    <img src="<?php echo e($post->image); ?>" width=100px height=100px>
    <br>
    <a href="<?php echo e(url("update_post/$post->id")); ?>">Update Post</a>
   </p> 
    <p>
    <a href="<?php echo e(url("/Comments/$post->id")); ?>">Comments</a>
    </p>
    <br>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>