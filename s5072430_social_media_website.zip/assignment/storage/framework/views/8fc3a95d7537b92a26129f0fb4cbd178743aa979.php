<?php $__env->startSection('title'); ?>
Add New Comment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Add New Comment</h1>
<div class="container2">
   <form method="post" action="/add_comment_action">
      <?php echo e(csrf_field()); ?>

      <p>
         <label>Enter ID:</label><br>
         <input type="integer" name="post_id">
      </p>
      <p>
         <label>Your Name:</label><br>
         <input type="text" name="name">
      </p>
      <p>
         <label>Image:</label><br>
         <input type="hidden" name="image" value="big-fork-black.jpg">
      </p>
      <p>
         <label>Description:</label><br>
         <textarea name="description"></textarea>
      </p>
      <input type="submit" value="Add Comment">
   </form>
   <br>
   <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>