<?php $__env->startSection('title'); ?>
  Post Details
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container2">
    <p>
    <h1><?php echo e($posts->name); ?></h1>
    <h1><?php echo e($posts->title); ?></h1>
    <h2><?php echo e($posts->description); ?></h2>
    <?php echo e($posts->image); ?>

   </p> 
    <p>
    <a href="<?php echo e(url("/Comments/$posts->id")); ?>">Comments</a>
        </p>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>