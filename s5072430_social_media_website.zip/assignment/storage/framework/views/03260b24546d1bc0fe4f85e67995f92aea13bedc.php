<?php $__env->startSection('title'); ?>
  Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body>
<br>
<div class ="container2">
<?php if($posts): ?>
    <p>
        <ul>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <li><a href="<?php echo e(url("Post_Details/$post->id")); ?>"><?php echo e($post->name); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    No Item Found
    <?php endif; ?>
<br>
</div>
<div class="container">
    <br>

</ul>
   </p>
   <p>
        
   </p>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>