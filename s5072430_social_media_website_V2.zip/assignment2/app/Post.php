<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = ['name', 'title', 'description', 'privacy'];
    function comments(){
        return $this->hasMany('App\Comment');
    }
}
