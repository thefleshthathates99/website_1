<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Friend_User extends Model
{
    function users() {
        return $this->hasMany('App\User');
    }
}
