<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\Comment;
use App\Http\User;
class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        /**
         *Sends the Posts view to the page 
         * and paginates the results 5 at a time
         */
       $posts = Post::paginate(5);
       return view('Posts')->with('posts', $posts);
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        /**
         * Returns the add_post view, following
         * the framework of the previous submission 
         */
        return view('add_post');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /**
         * 
         * Retrieves all data from the add_post
         * form and saves the data to the Database
         * then redirecting to the post that was
         * just added. Includes validation
         */
        $this->validate($request, [
            'name' => 'required|max:255',
            'title' => 'required|max:255',
            'description' =>'required|min:6|max:2000',
            'privacy' => 'required',
            'poster_id' => 'required'
            ]);
         
        $post = new Post();
        $post->name = $request->name;
        $post->title = $request->title;
        $post->description = $request->description;
        $post->privacy = $request->privacy;
        $post->poster_id = $request->poster_id;
        $post->save();
        return redirect("/post/$post->id");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        /**
         * 
         * This is essentially the "comments" controller
         * displaying the comments belonging to that post.
         * It then paginates the comments by 6 at a time.
         * One problem with this is the fact that
         * I personally implemented it without deviating
         * from the original framework from submisssion 1.
         * 
         */
        $posts = Post::all()->where('id', '=', $id);
        $comments = Comment::where('post_id', '=', $id)->paginate(6);
        return view('Comments')->with('posts', $posts)->with('comments', $comments);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        /**
         * Retrieves the post whose id matches the ID
         * in the "url". The first() part of it is because it seems
         * to return an array and using get() doesn't work
         * with the page, although I am not profficient with
         * PHP and Laravel
         */
        $posts = Post::all()->where('id', '=', $id)->first();
        return view('update_post')->with('posts', $posts);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        /**
         * Similar to the store() function, retrieving data,
         * storing it and saving it to the DB
         */
        $post = Post::find($id);
        $post->name = $request->name;
        $post->title = $request->title;
        $post->description = $request->description;
        $post->save();
        return redirect("/post/$post->id");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        /**
         * Calls the delete function on the post
         * with the $id in the url, then redirecting to Home
         */
        $post = Post::find($id);
        $post->delete();
        return redirect("/");
    }
    
    
    
}


