<?php $__env->startSection('title'); ?>
Add New Post
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Add New Post</h1>
<div class="container2">
   <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <h2>Are you sure you want to add "<?php echo e($name->name); ?>" as a friend?</h2>
   <form method="post" action="/friend_user">
      <?php echo e(csrf_field()); ?>

      <?php $auth_user = Auth::user(); ?>
      <input  type="hidden" name="id_1" value="<?php echo e($auth_user->id); ?>">
      <input  type="hidden" name="id_1_name" value="<?php echo e($auth_user->name); ?>">
      <input  type="hidden" name="id_2" value="<?php echo e($name->id); ?>">
      <input  type="hidden" name="id_2_name" value="<?php echo e($name->name); ?>">
      <input type="submit" value="Add Friend">
   </form>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <br>
   <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>