<?php $__env->startSection('title'); ?>
Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>
<link rel="stylesheet" type="text/css" href="css/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<body>
   <div class="container">
      Welcome to the Washington Redskins social media website
   </div>
   <br>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="container2">
      <h1><?php echo e($user->name); ?></h1>
      <h1><?php echo e($user->email); ?></h1>
      <img src="<?php echo e(url($user->image)); ?>" alt="profile image" style="width:150px;height:150px;">
      <img src="user_images/<?php echo e(url($user->image)); ?>">
      
<?php if(Auth::check()): ?>
<?php $auth_id = Auth::id(); 
      $now_date = new DateTime;
      $dob = (int)$user->DOB;
      $age = 2017 - $dob;
?>

         <h1>Age:</h1>
         <h2><?php echo e($age); ?></h2>
         <?php if($auth_id = $user->id): ?>
            <h1>Friends:</h1>
         <?php endif; ?>
         <h2><a href="/add_friend/<?php echo e($user->id); ?>">Add as Friend</a></h2>

<?php else: ?>
<?php endif; ?>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>