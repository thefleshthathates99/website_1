<?php $__env->startSection('title'); ?>
Add New Comment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Add New Comment</h1>
<div class="container2">
   <form method="post" action="/comment">
      <?php echo e(csrf_field()); ?>

      
         <?php if(count($errors) > 0): ?>
            <div class="alert">
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
         <?php endif; ?>

      <p>
         <label>Enter ID:</label><br>
         <input type="text" name="post_id">
      </p>
      <p>
         <?php
         $user = Auth::user();
         ?>
         
         <br>
         <input type="hidden" name="name" value="<?php echo e($user->name); ?>">
      </p>
      <p>
        <!--- <label>Image:</label><br>
         <input type="hidden" name="image" value="big-fork-black.jpg">--->
      </p>
      <p>
         <label>Description:</label><br>
         <textarea name="description"></textarea>
      </p>
      <input type="submit" value="Add Comment">
   </form>
   <br>
   <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>