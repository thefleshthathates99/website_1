<?php $__env->startSection('title'); ?>
Comments
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::guest()): ?>
<?php else: ?>
<a href="<?php echo e(url("/comment/create")); ?>">Add a Comment</a>
<?php endif; ?>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container3">
   <h1 class="bold"><?php echo e($post->name); ?></h1>
   <h1 class="bold"><?php echo e($post->title); ?></h1>
   <h2 class="bold"><?php echo e($post->description); ?></h2>
   <!---<div class="bold"><img src="../<?php echo e($post->image); ?>" width=100px height=100px></div>--->
   <?php if(Auth::id() != $post->poster_id): ?>
   <?php else: ?>
   <a href="<?php echo e(url("post/$post->id/edit")); ?>">Update Post</a>
   <br>
   <a href="<?php echo e(url("post/$post->id/destroy")); ?>">Delete Post</a>
   </p> 
   <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container2">
   <p>
   <h1><?php echo e($comment->name); ?></h1>
   <h1><?php echo e($comment->description); ?></h1>
   <!---<h2><img src="../<?php echo e($comment->image); ?>" width=100px height=100px></h2>--->
   </p> 
   <br>
   <?php if(Auth::id() != $post->poster_id): ?>
   <?php else: ?>
   <a href="<?php echo e(url("comment/$comment->id/destroy")); ?>">Delete Comment</a>
   <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php echo e($comments->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>