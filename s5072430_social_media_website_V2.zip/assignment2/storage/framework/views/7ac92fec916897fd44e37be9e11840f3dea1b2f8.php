<?php $__env->startSection('title'); ?>
Update a Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Update Post</h1>
<div class="container2">
   <form method="post" action="/post/<?php echo e($posts->id); ?>">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PUT')); ?>

      <p>
         <input type="hidden" name="id" value="<?php echo e($posts->id); ?>">
      </p>
      <p>
         <label>Your Name:</label><br>
         <input type="text" name="name" value="<?php echo e($posts->name); ?>">
      </p>
      <p>
         <label>Title of your Post:</label><br>
         <input type="text" name="title" value="<?php echo e($posts->title); ?>">
      </p>
      <p>
        <!--- <label>Image:</label><br>
         <input type="text" name="image" value="<?php echo e($posts->image); ?>">--->
      </p>
      <p>
         <label>Description:</label><br>
         <textarea name="description"><?php echo e($posts->description); ?></textarea>
      </p>
      <input type="submit" value="Update Post">
   </form>
   <br>
   <br>
   <a href="<?php echo e(url("/post/$posts->id")); ?>">Cancel</a>
   <br>
   <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>