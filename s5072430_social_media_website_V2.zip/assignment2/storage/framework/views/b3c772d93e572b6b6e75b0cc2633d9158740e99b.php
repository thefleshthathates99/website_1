<?php $__env->startSection('title'); ?>
Results
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>
<link rel="stylesheet" type="text/css" href="css/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<body>
   <div class = "container">
      <form  method="get" action="/search"> 
         <input  type="text" name="username"> 
         <input  type="submit" name="submit" value="Search"> 
      </form> 
   </div>
   <br>
   <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="container2">
      <h1><a href="user/<?php echo e($name->id); ?>"><?php echo e($name->name); ?></h1>
      <br>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>