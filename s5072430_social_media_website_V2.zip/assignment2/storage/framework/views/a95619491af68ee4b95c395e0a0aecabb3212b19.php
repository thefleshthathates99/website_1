<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>
<link rel="stylesheet" type="text/css" href="css/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<body>
   <div class="container">
      Welcome to the Washington Redskins social media website.
      <br>
      Please Login Above!
   </div>
   <div class="container">
   </div>
      <div class = "container2">
      <form  method="get" action="/search"> 
         <input  type="text" name="username"> 
         <input  type="submit" name="submit" value="Search For Users"> 
      </form> 
   </div>
   <br>
   <br>
   <br>
   <a href='/documentation'>Documentation Link</a>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>