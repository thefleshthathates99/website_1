<?php $__env->startSection('title'); ?>
Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('stylesheet'); ?>
<link rel="stylesheet" type="text/css" href="css/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<body>
   <div class="container">
      Welcome to the Washington Redskins social media website
   </div>
   <div class="container">
      
   </div>
   <br>
   <?php if(Auth::guest()): ?>
   <?php else: ?>
   <p>
      <a href="<?php echo e(url("/post/create")); ?>">Add a New Post</a>
   </p>
   <?php endif; ?>
   <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="container2">
               <h1><?php echo e($post->name); ?></h1>
               <h1><?php echo e($post->title); ?></h1>
               <h2><?php echo e($post->description); ?></h2>
               <h3><?php echo e($post->privacy); ?></h3>
               <h3><?php echo e($post->updated_at); ?></h3>
               <!---<img src="<?php echo e($post->image); ?>" width=100px height=100px>--->
               <br>
                  <?php if(Auth::id() != $post->poster_id): ?>
                  <?php else: ?>
               <a href="<?php echo e(url("post/$post->id/edit")); ?>">Update Post</a>
               <?php endif; ?>
               </p>
               <p>
                  <a href="<?php echo e(url("/post/$post->id")); ?>">Comments</a>
               </p>
               <br>
            </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php echo e($posts->links()); ?>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>