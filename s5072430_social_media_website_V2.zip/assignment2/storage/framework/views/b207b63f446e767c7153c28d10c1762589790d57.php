<?php $__env->startSection('title'); ?>
Comments
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(url("/add_comments")); ?>">Add a Comment</a>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container3">
   <h1 class="bold"><?php echo e($post->name); ?></h1>
   <h1 class="bold"><?php echo e($post->title); ?></h1>
   <h2 class="bold"><?php echo e($post->description); ?></h2>
   <div class="bold"><img src="../<?php echo e($post->image); ?>" width=100px height=100px></div>
   <a href="<?php echo e(url("update_post/$post->id")); ?>">Update Post</a>
   <br>
   <a href="<?php echo e(url("delete_post_action/$post->id")); ?>">Delete Post</a>
   </p> 
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container2">
   <p>
   <h1><?php echo e($comment->name); ?></h1>
   <h1><?php echo e($comment->description); ?></h1>
   <h2><img src="../<?php echo e($comment->image); ?>" width=100px height=100px></h2>
   </p> 
   <br>
   <a href="<?php echo e(url("delete_comment_action/$comment->id")); ?>">Delete Comment</a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>