<?php $__env->startSection('title'); ?>
Add New Post
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Add New Post</h1>
<div class="container2">
   <form method="post" action="/post">
      <?php echo e(csrf_field()); ?>

         <?php if(count($errors) > 0): ?>
            <div class="alert">
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
         <?php endif; ?>
      <p>
         <?php
         $user = Auth::user();
         ?>
         
         <input type="hidden" name="name" value="<?php echo e($user->name); ?>">
      </p>
      <p>
         <label>Title of your Post:</label><br>
         <input type="text" name="title">
      </p>
      <p>
         
         <input type="hidden" name="poster_id" value="<?php echo e(Auth::id()); ?>">
      </p>
      <p>
         <label>Description:</label><br>
         <textarea name="description"></textarea>
      </p>
      <p>
         <label>Privacy</label><br>
           <input type="radio" name="privacy" value="Pr">Private<br>
           <input type="radio" name="privacy" value="Fr">Friends Only<br>
           <input type="radio" name="privacy" value="Pu">Public
      </p>
      <input type="submit" value="Add Post">
   </form>
   <br>
   <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>