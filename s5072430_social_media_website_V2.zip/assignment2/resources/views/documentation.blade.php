@extends('layouts.app')

@section('title')
Documentation
@endsection

@section('stylesheet')
<link rel="stylesheet" type="text/css" href="css/style.css">
@endsection
@section('content')
<h1>Web App Development Assignment 2 Documentation</h1>
<h2>ER Diagram</h2>
<img src="css/erd.JPG" width='650px' height='550px'>
<br>
<br>
<h2>Tasks Completed</h2>
<br>
The tasks were determined from the marking rubric. The tasks completed are:
<ul>
    <li>User Search (Partially)</li>
    <li>Convert assignment 1 to Controllers, Migration, Views etc.</li>
    <li>Logged Out Functions</li>
    <li>Logged In Functions</li>
    <li>Image Handling/Uploading</li>
    <li>User Authentication</li>
    <li>Validation</li>
</ul>
<br>
The tasks not completed include:
<ul>
    <li>Friend Functions</li>
</ul>
<br>
<h2>Approach Taken</h2>
I essentially followed the assignment development strategy of:
<br>
<img src="css/design.JPG">
<br>
<h2>Other Details</h2>
Much like the previous assignment, “dead/test code” may remain in some parts of the assignment due to my personal rushed schedule with the project, though this is a personal issue.
<br>
User search could not be completed due to some issue with the SQL and how Laravel won’t seem to accept LIKE as a parameter in the User Controller

@endsection