@extends('layouts.app')

@section('title')
Posts
@endsection

@section('stylesheet')
<link rel="stylesheet" type="text/css" href="css/style.css">
@endsection
@section('content')
<body>
   <div class="container">
      Welcome to the Washington Redskins social media website
   </div>
   <br>
      @foreach ($users as $user)
   <div class="container2">
      <h1>{{$user->name}}</h1>
      <h1>{{$user->email}}</h1>
      <img src="{{url($user->image)}}" alt="profile image" style="width:150px;height:150px;">
      <img src="user_images/{{url($user->image)}}">
      
@if (Auth::check())
<?php $auth_id = Auth::id(); 
      $now_date = new DateTime;
      $dob = (int)$user->DOB;
      $age = 2017 - $dob;
?>

         <h1>Age:</h1>
         <h2>{{$age}}</h2>
         @if ($auth_id = $user->id)
            <h1>Friends:</h1>
         @endif
         <h2><a href="/add_friend/{{$user->id}}">Add as Friend</a></h2>

@else
@endif
   </div>
   @endforeach
   @endsection