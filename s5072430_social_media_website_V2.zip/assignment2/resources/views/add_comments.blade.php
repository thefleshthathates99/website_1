@extends('layouts.app')

@section('title')
Add New Comment
@endsection

@section('content')
<h1>Add New Comment</h1>
<div class="container2">
   <form method="post" action="/comment">
      {{csrf_field()}}
      
         @if (count($errors) > 0)
            <div class="alert">
            <ul>
            @foreach ($errors->all() as $error)
               <li>{{ $error }}</li>
            @endforeach
            </ul>
            </div>
         @endif

      <p>
         <label>Enter ID:</label><br>
         <input type="text" name="post_id">
      </p>
      <p>
         <?php
         $user = Auth::user();
         ?>
         
         <br>
         <input type="hidden" name="name" value="{{$user->name}}">
      </p>
      <p>
        <!--- <label>Image:</label><br>
         <input type="hidden" name="image" value="big-fork-black.jpg">--->
      </p>
      <p>
         <label>Description:</label><br>
         <textarea name="description"></textarea>
      </p>
      <input type="submit" value="Add Comment">
   </form>
   <br>
   <br>
</div>
@endsection