@extends('layouts.app')

@section('title')
Update a Post
@endsection

@section('content')
<h1>Update Post</h1>
<div class="container2">
   <form method="post" action="/post/{{$posts->id}}">
      {{csrf_field()}}
      {{ method_field('PUT') }}
      <p>
         <input type="hidden" name="id" value="{{$posts->id}}">
      </p>
      <p>
         <label>Your Name:</label><br>
         <input type="text" name="name" value="{{$posts->name}}">
      </p>
      <p>
         <label>Title of your Post:</label><br>
         <input type="text" name="title" value="{{$posts->title}}">
      </p>
      <p>
        <!--- <label>Image:</label><br>
         <input type="text" name="image" value="{{$posts->image}}">--->
      </p>
      <p>
         <label>Description:</label><br>
         <textarea name="description">{{$posts->description}}</textarea>
      </p>
      <input type="submit" value="Update Post">
   </form>
   <br>
   <br>
   <a href="{{url("/post/$posts->id")}}">Cancel</a>
   <br>
   <br>
</div>
@endsection