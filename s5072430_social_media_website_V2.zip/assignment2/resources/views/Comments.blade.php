@extends('layouts.app')

@section('title')
Comments
@endsection

@section('content')
@if (Auth::guest())
@else
<a href="{{url("/comment/create")}}">Add a Comment</a>
@endif
@foreach ($posts as $post)
<div class="container3">
   <h1 class="bold">{{$post->name}}</h1>
   <h1 class="bold">{{$post->title}}</h1>
   <h2 class="bold">{{$post->description}}</h2>
   <!---<div class="bold"><img src="../{{$post->image}}" width=100px height=100px></div>--->
   @if (Auth::id() != $post->poster_id)
   @else
   <a href="{{url("post/$post->id/edit")}}">Update Post</a>
   <br>
   <a href="{{url("post/$post->id/destroy")}}">Delete Post</a>
   </p> 
   @endif
</div>
@endforeach
@foreach ($comments as $comment)
<div class="container2">
   <p>
   <h1>{{$comment->name}}</h1>
   <h1>{{$comment->description}}</h1>
   <!---<h2><img src="../{{$comment->image}}" width=100px height=100px></h2>--->
   </p> 
   <br>
   @if (Auth::id() != $post->poster_id)
   @else
   <a href="{{url("comment/$comment->id/destroy")}}">Delete Comment</a>
   @endif
</div>
@endforeach
   {{$comments->links()}}
@endsection