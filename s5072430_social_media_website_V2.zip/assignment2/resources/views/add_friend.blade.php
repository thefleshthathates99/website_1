@extends('layouts.app')
@section('title')
Add New Post
@endsection
@section('content')
<h1>Add New Post</h1>
<div class="container2">
   @foreach ($names as $name)
   <h2>Are you sure you want to add "{{$name->name}}" as a friend?</h2>
   <form method="post" action="/friend_user">
      {{csrf_field()}}
      <?php $auth_user = Auth::user(); ?>
      <input  type="hidden" name="id_1" value="{{$auth_user->id}}">
      <input  type="hidden" name="id_1_name" value="{{$auth_user->name}}">
      <input  type="hidden" name="id_2" value="{{$name->id}}">
      <input  type="hidden" name="id_2_name" value="{{$name->name}}">
      <input type="submit" value="Add Friend">
   </form>
   @endforeach
   <br>
   <br>
</div>
@endsection