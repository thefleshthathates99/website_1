@extends('layouts.app')

@section('title')
Home
@endsection

@section('stylesheet')
<link rel="stylesheet" type="text/css" href="css/style.css">
@endsection
@section('content')
<body>
   <div class="container">
      Welcome to the Washington Redskins social media website.
      <br>
      Please Login Above!
   </div>
   <div class="container">
   </div>
      <div class = "container2">
      <form  method="get" action="/search"> 
         <input  type="text" name="username"> 
         <input  type="submit" name="submit" value="Search For Users"> 
      </form> 
   </div>
   <br>
   <br>
   <br>
   <a href='/documentation'>Documentation Link</a>
   @endsection