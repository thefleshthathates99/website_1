@extends('layouts.app')
@section('title')
Add New Post
@endsection
@section('content')
<h1>Add New Post</h1>
<div class="container2">
   <form method="post" action="/post">
      {{csrf_field()}}
         @if (count($errors) > 0)
            <div class="alert">
            <ul>
            @foreach ($errors->all() as $error)
               <li>{{ $error }}</li>
            @endforeach
            </ul>
            </div>
         @endif
      <p>
         <?php
         $user = Auth::user();
         ?>
         
         <input type="hidden" name="name" value="{{$user->name}}">
      </p>
      <p>
         <label>Title of your Post:</label><br>
         <input type="text" name="title">
      </p>
      <p>
         
         <input type="hidden" name="poster_id" value="{{Auth::id()}}">
      </p>
      <p>
         <label>Description:</label><br>
         <textarea name="description"></textarea>
      </p>
      <p>
         <label>Privacy</label><br>
           <input type="radio" name="privacy" value="Pr">Private<br>
           <input type="radio" name="privacy" value="Fr">Friends Only<br>
           <input type="radio" name="privacy" value="Pu">Public
      </p>
      <input type="submit" value="Add Post">
   </form>
   <br>
   <br>
</div>
@endsection