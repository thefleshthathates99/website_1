@extends('layouts.app')

@section('title')
Posts
@endsection

@section('stylesheet')
<link rel="stylesheet" type="text/css" href="css/style.css">
@endsection
@section('content')
<body>
   <div class="container">
      Welcome to the Washington Redskins social media website
   </div>
   <div class="container">
      
   </div>
   <br>
   @if (Auth::guest())
   @else
   <p>
      <a href="{{url("/post/create")}}">Add a New Post</a>
   </p>
   @endif
   @foreach ($posts as $post)

            <div class="container2">
               <h1>{{$post->name}}</h1>
               <h1>{{$post->title}}</h1>
               <h2>{{$post->description}}</h2>
               <h3>{{$post->privacy}}</h3>
               <h3>{{$post->updated_at}}</h3>
               <!---<img src="{{$post->image}}" width=100px height=100px>--->
               <br>
                  @if (Auth::id() != $post->poster_id)
                  @else
               <a href="{{url("post/$post->id/edit")}}">Update Post</a>
               @endif
               </p>
               <p>
                  <a href="{{url("/post/$post->id")}}">Comments</a>
               </p>
               <br>
            </div>
   @endforeach
   {{$posts->links()}}
   @endsection