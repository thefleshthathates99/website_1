@extends('layouts.app')

@section('title')
Results
@endsection

@section('stylesheet')
<link rel="stylesheet" type="text/css" href="css/style.css">
@endsection
@section('content')
<body>
   <div class = "container">
      <form  method="get" action="/search"> 
         <input  type="text" name="username"> 
         <input  type="submit" name="submit" value="Search"> 
      </form> 
   </div>
   <br>
   @foreach ($names as $name)
   <div class="container2">
      <h1><a href="user/{{$name->id}}">{{$name->name}}</h1>
      <br>
   </div>
   @endforeach
   @endsection