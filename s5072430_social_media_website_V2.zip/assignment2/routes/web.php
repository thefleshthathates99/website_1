<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use App\Post;
use App\Comment;
use App\Http\User;
use App\Friend_User;

Route::resource('post', 'PostController');
Route::resource('comment', 'CommentController');
Route::resource('user', 'UserController');
Route::resource('friend_user', 'Friend_userController');

Route::get('/', function () {
   $posts = Post::all();
   return view('Home')->with('posts', $posts);

});

Route::get('/post/{id}/destroy', function ($id) {
    $post = Post::find($id);
    $post->delete();
    return redirect("/");

});

Route::get('/comment/{id}/destroy', function ($id) {
    $comment = Comment::find($id);

});

Route::get('/search', function() {
        $query = "select * from users where name = ?";
        $names = DB::select($query, array($_GET['username']));
        return view('results')->with('names', $names);
        
});

Route::get('/add_friend/{id}', function($id) {
        $query = "select * from users where id = $id";
        $names = DB::select($query);
        return view('add_friend')->with('names', $names);
        
});

Route::get('/documentation', function() {
        return view('documentation');
});

        
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
