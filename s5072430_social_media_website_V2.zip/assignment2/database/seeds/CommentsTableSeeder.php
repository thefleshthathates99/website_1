<?php

use Illuminate\Database\Seeder;

class CommentsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    
        
    /**
     * Seeds the comments table
     */
     
    {
        DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_1",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_2",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_3",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_4",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_5",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_6",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_7",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_8",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_9",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            DB::table('comments')->insert([
            'name' => "Bob Sagat",
            'description' => "Comment_10",
            'post_id' => 1,
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            
            ]);
            
            
    }
}