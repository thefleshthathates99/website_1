<?php

use Illuminate\Database\Seeder;

class friend_userSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('friend_users')->insert([
            "id_1" => 0,
            "id_1_name" => "null",
            "id_2" => 0,
            "id_2_name" => "null",
            
            ]);
            
        DB::table('friend_users')->insert([
            "id_1" => 1,
            "id_1_name" => "Bob Sagat",
            "id_2" => 2,
            "id_2_name" => "John Hancock",
            
            ]);   
    }
}
