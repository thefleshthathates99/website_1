<?php

use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    
    /**
     * Seeds the User table
     */
    {
        DB::table('users')->insert([
            "name" => "Bob Sagat",
            "email" => "Bob@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 2,
            "DOB" => 1997-12-03,
            "image" => "user_images/beard.jpg",
            ]);
            
        DB::table('users')->insert([
            "name" => "John Hancock",
            "email" => "John@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 2,
            "DOB" => 1997-23-04,
            "image" => "user_images/none",
        
        ]);
        
        DB::table('users')->insert([
            "name" => "Tom Selic",
            "email" => "Tom@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 0,
            "DOB" => 1997-12-11,
            "image" => "user_images/none",
        ]);
        
        DB::table('users')->insert([
            "name" => "Jess Hart",
            "email" => "Jess@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 0,
            "DOB" => 1997-6-8,
            "image" => "user_images/none",
        ]);
        
        DB::table('users')->insert([
            "name" => "Maddie Wraith",
            "email" => "Maddie@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 0,
            "DOB" => 1998-1-1,
            "image" => "user_images/none",
        ]);
        
        DB::table('users')->insert([
            "name" => "Ryan Weast",
            "email" => "Ryan@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 0,
            "DOB" => 2000-11-11,
            "image" => "user_images/none",
        ]);
        
        DB::table('users')->insert([
            "name" => "Mitchell Young",
            "email" => "Mitchell@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 0,
            "DOB" => 1992-25-4,
            "image" => "user_images/none",
        ]);
        
        DB::table('users')->insert([
            "name" => "Shaun Ericson",
            "email" => "Shaun@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 0,
            "DOB" => 1997-12-3,
            "image" => "user_images/none",
        ]);
        
        DB::table('users')->insert([
            "name" => "Zane Belvue",
            "email" => "Zane@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 0,
            "DOB" => 1998-11-2,
            "image" => "user_images/beard.jpg",
        ]);
        
        DB::table('users')->insert([
            "name" => "Matt Haesberg",
            "email" => "Matt@a.org",
            "password" => bcrypt("1234"),
            "friend_code" => 0,
            "DOB" => 1991-1-1,
            "image" => "user_images/none",
        ]);
        
    }
}
