<?php

use Illuminate\Database\Seeder;

class PostsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    
        
    /**
     * Seeds the posts table
     */
     
    {
        DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_1",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_2",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_3",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_4",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_5",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_6",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_7",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_8",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_9",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "John Hancock",
            'poster_id' => 2,
            'title' => "Posts",
            'description' => "Post_10",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "Bob Sagat",
            'poster_id' => 1,
            'title' => "Bob's Post 1",
            'description' => "Bob's Public Post",
            'privacy' => 'Pu',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "Bob Sagat",
            'poster_id' => 1,
            'title' => "Bob's Post 2",
            'description' => "Bob's Friends Post",
            'privacy' => 'F',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);
            
            DB::table('posts')->insert([
            'name' => "Bob Sagat",
            'poster_id' => 1,
            'title' => "Bob's Post 3",
            'description' => "Bob's Private Post",
            'privacy' => 'Pr',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
            ]);


    }
}
