<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        /**
         * Creates both the posts and comments tables
         */
        Schema::create('posts',
        function(Blueprint $table){
            $table->increments('id');
            $table->string('name');
            $table->integer('poster_id');
            $table->string('title');
            $table->string('description');
            $table->string('privacy');
            $table->timestamps();
            
           /*Needs Image*/ 
        });
        
        Schema::create('comments',
        function(Blueprint $table){
            $table->increments('id');
            $table->string('name');
            $table->string('description');
            /*Needs Image*/
            $table->integer('post_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExsits('products');
        Schema::dropIfExsits('comments');
    }
}
